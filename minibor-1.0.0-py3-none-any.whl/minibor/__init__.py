"""
Minibor - Einfache Python-Bibliothek fur MiniborAI API
"""

from .client import MiniborClient

__version__ = "1.0.0"
__all__ = ["MiniborClient"]

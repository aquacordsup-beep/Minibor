import requests

class MiniborClient:
    """
    Einfacher Client fur MiniborAI API
    
    Beispiel:
    from minibor import MiniborClient
    client = MiniborClient()
    antwort = client.chat("Hallo! Wie wird das Wetter?")
    print(antwort["response"])
    """
    
    def __init__(self, timeout=30):
        self.base_url = "http://api.miniborai.com"  # ← KORREKTE URL MIT PORT!
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json"
        })
    
    def chat(self, message):
        url = f"{self.base_url}/api/chat"
        data = {"message": message}
        
        try:
            response = self.session.post(url, json=data, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "error": str(e),
                "response": f"API-Fehler: {e}"
            }
    
    def ask(self, question):
        result = self.chat(question)
        if result.get("success"):
            return result.get("response", "")
        return f"Fehler: {result.get('error', '')}"
    
    def close(self):
        self.session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
